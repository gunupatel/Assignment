const capg_locations = ["Bangal", "Bangalore", "Goa", "Kolkata"];
document.write(capg_locations.reverse());