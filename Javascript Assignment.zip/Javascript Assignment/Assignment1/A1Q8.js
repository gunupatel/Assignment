const letters = ['a', 'b', 'c'];
const numbers = [1,2,3];

const alphaNumeric = letters.concat(numbers);
document.write(alphaNumeric);