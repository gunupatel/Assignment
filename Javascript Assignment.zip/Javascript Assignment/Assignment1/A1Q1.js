var num=5;
var sum=0;
for(i=1;i<=num;i++){
    sum=sum+i;
}
document.write(sum);
