var year = prompt("please enter a year to find out the next 20 leap years");
var counter = 20;
var result=true;

while(counter >= 0){
    if((year % 4 == 0) && (year % 100 !=0) || (year % 400 ==0)){
        result = true;
        document.write(year);
        year++;
        counter--;
    }
    else {
        year++;
    }
}
