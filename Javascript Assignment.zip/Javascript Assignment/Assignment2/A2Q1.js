function square(x){
    return x*x;
}
function double(x){
    return x*2;
}
function compose(f1,f2){
    function composevalue(x){
        return (f1(f2(x)));
    }
    let result = composevalue(x);
    document.write(result, "<br>");
    console.log(result);
}
let x=prompt("Enter a number:");
var a=compose(square,double);
var b=compose(double,square);
