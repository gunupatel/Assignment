function person(fname,lname,age,skills,dob,address,married,profession){
    this.fname= fname;
    this.lname= lname;
    this.age = age;
    this.skills= skills;
    this.dob= dob;
    this.address= address;
    this.married= married;
    this.profession= profession;
};
person1 = new person("Gunjan","Kumari",34,"C++","07/06/2000",{city: "ranchi",pincode: "759018"}, "false","developer");
person2 = new person("rekha","Kumari",44,"java","07/06/1990",{city: "dhanbad",pincode: "759246"}, "false","analyst");
print = function(){
    console.log(person1);
    console,log(person2);

}();
