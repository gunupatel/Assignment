const obj={
    firstName: "Gunjan",
    lastname: "Kumari"

}
obj.middleName="Patel";
document.write(obj.middleName);